﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace RecupereJa.Data
{
    public class RecupereJaContextFactory : IDesignTimeDbContextFactory<RecupereJaContext>
    {
        public RecupereJaContext CreateDbContext(string[] args)
        {
            // Define configuração (lendo do appsettings.json)
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false)
                .Build();

            var connectionString = configuration.GetConnectionString("DefaultConnection");

            var optionsBuilder = new DbContextOptionsBuilder<RecupereJaContext>();
            optionsBuilder.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 39)));

            return new RecupereJaContext(optionsBuilder.Options);
        }
    }
}
