﻿namespace RecupereJa.Enums
{
    public enum PrioridadeEnum
    {
        Baixa = 1,
        Media = 2,
        Alta = 3
    }
}
